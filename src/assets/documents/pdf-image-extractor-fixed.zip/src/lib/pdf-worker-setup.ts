
import * as pdfjsLib from 'pdfjs-dist/legacy/build/pdf'
/**
 * Robust PDF worker setup:
 * - Prefer bundler-copied worker URL via `?url` (Vite/Rollup/webpack asset loader).
 * - Fallback to same-origin /assets/pdf.worker.min.js if available.
 * - If worker cannot be fetched, we set to disableWorker mode and allow client to retry with disableWorker.
 */

// Try to import worker URL using bundler ?url. This will be rewritten by bundlers that support it (Vite, webpack with asset-loader).
let bundledWorkerUrl: string | null = null
try {
  // @ts-ignore - bundlers understand ?url
  bundledWorkerUrl = require('pdfjs-dist/legacy/build/pdf.worker.min.js?url') as string
} catch (err) {
  try {
    // ES module style import may also work in some setups; lazy require above is safer for TS compile.
    // do nothing
  } catch (e) {}
}

// Common fallback path if you manually copied worker to public/assets
const FALLBACK_ASSET_PATH = '/assets/pdf.worker.min.js'

let workerInitialized = false
let workerInitError: Error | null = null
let workerMode: 'worker' | 'no-worker' = 'no-worker'
let resolvedWorkerUrl: string | null = null

// set empty default to avoid pdfjs trying to fetch unknown URL
if (typeof pdfjsLib.GlobalWorkerOptions !== 'undefined') {
  pdfjsLib.GlobalWorkerOptions.workerSrc = ''
}

async function tryFetchWorker(url: string, timeout = 4000): Promise<boolean> {
  try {
    const controller = new AbortController()
    const id = setTimeout(() => controller.abort(), timeout)
    const res = await fetch(url, { method: 'HEAD', signal: controller.signal })
    clearTimeout(id)
    return res && res.ok
  } catch (e) {
    return false
  }
}

export async function initializePDFWorker(): Promise<{ success: boolean; error?: Error; mode: 'worker' | 'no-worker' }> {
  if (workerInitialized) {
    return { success: true, mode: workerMode }
  }
  // 1) try bundledWorkerUrl (from ?url)
  if (bundledWorkerUrl) {
    const ok = await tryFetchWorker(bundledWorkerUrl)
    if (ok) {
      pdfjsLib.GlobalWorkerOptions.workerSrc = bundledWorkerUrl
      workerInitialized = true
      workerMode = 'worker'
      resolvedWorkerUrl = bundledWorkerUrl
      return { success: true, mode: 'worker' }
    }
  }

  // 2) try fallback asset path
  const okFallback = await tryFetchWorker(FALLBACK_ASSET_PATH)
  if (okFallback) {
    pdfjsLib.GlobalWorkerOptions.workerSrc = FALLBACK_ASSET_PATH
    workerInitialized = true
    workerMode = 'worker'
    resolvedWorkerUrl = FALLBACK_ASSET_PATH
    return { success: true, mode: 'worker' }
  }

  // 3) try CDN (last resort) - keep existing version if you want; but do not rely on it
  try {
    const cdnUrl = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/5.4.449/pdf.worker.min.mjs`
    const okCdn = await tryFetchWorker(cdnUrl, 3000)
    if (okCdn) {
      pdfjsLib.GlobalWorkerOptions.workerSrc = cdnUrl
      workerInitialized = true
      workerMode = 'worker'
      resolvedWorkerUrl = cdnUrl
      return { success: true, mode: 'worker' }
    }
  } catch (e) {
    // ignore
  }

  // 4) If none worked, set disableWorker mode (client main-thread)
  workerInitialized = true
  workerMode = 'no-worker'
  workerInitError = new Error('Could not initialize pdf.worker: worker asset not reachable; will use disableWorker fallback')
  return { success: false, error: workerInitError, mode: 'no-worker' }
}

export function isWorkerInitialized(): boolean {
  return workerInitialized
}

export function getWorkerError(): Error | null {
  return workerInitError
}

export function getWorkerMode(): 'worker' | 'no-worker' {
  return workerMode
}

export function getResolvedWorkerUrl(): string | null {
  return resolvedWorkerUrl
}
